# Changelog

## [1.0.0] - 2025-07-16

### Added
- Initial release of Procedural Lighting System
- Procedural light generation with 5 pattern types (Circle, Grid, Random, Spiral, Wave)
- Advanced light management with grouping and parenting
- Volumetric lighting support
- Bloom effects integration
- Light animation system
- Preset management with built-in presets
- Performance optimization tools
- Comprehensive user interface
- Sample scene and documentation

### Features
- Compatible with Blender 4.1+
- Cycles render engine integration
- Export/import preset functionality
- Light baking support
- Automatic compositor setup for effects

### Requirements
- Blender 4.1 or higher
- Cycles render engine (for volumetrics)
- Compositor enabled (for bloom effects)

# Installation Guide

## Quick Install

1. **Download** the ZIP file
2. **Open Blender 4.1+**
3. Go to `Edit` �� `Preferences` �� `Add-ons`
4. Click `Install...` button
5. Select the downloaded ZIP file
6. **Enable** the "Procedural Lighting System" addon
7. **Done!** Find the addon in the 3D Viewport sidebar under "Lighting" tab

## Manual Install

1. Extract the ZIP file
2. Copy the `procedural_lighting_system` folder to:
   - **Windows**: `%APPDATA%\Blender Foundation\Blender\4.1\scripts\addons\`
   - **macOS**: `~/Library/Application Support/Blender/4.1/scripts/addons/`
   - **Linux**: `~/.config/blender/4.1/scripts/addons/`
3. Restart Blender
4. Enable the addon in preferences

## First Use

1. Open the 3D Viewport sidebar (press `N`)
2. Navigate to the "Lighting" tab
3. Find "Procedural Lighting" panel
4. Try the sample scene: Run `sample_scene.py` in Blender's text editor

## Troubleshooting

- **Addon not showing**: Check Blender version compatibility (4.1+)
- **Volumetrics not working**: Ensure Cycles render engine is selected
- **Bloom not appearing**: Enable compositor in the scene properties
- **Performance issues**: Use fewer lights or enable optimization tools

For more help, see the full README.md file.
